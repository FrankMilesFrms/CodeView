package com.frms.codeview.tools;

/**
 * 项目名称 ： APProject
 * 创建人 ： Frms
 * 创建人邮箱 ： 3505826836@qq.com
 * 创建时间 ： 2020/2/8 16:26(ydt)
 */
public abstract class Theme
{
    public abstract int getBackgroundColor();
    
    public abstract int getCursorColor();
    
    public abstract int getLineCountColor();
    
    public abstract int getLineRectColor();
    
    public abstract int getNormalColor();
    
    public abstract int getSelectColor();
}
