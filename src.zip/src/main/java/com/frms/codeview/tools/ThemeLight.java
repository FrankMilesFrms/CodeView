package com.frms.codeview.tools;

import android.graphics.Color;

/**
 * 项目名称 ： app
 * 创建人 ： Frms
 * 创建人邮箱 ： 3505826836@qq.com
 * 创建时间 ：2020/2/22 11:50(ydt)
 */
public class ThemeLight extends Theme
{
    
    
    @Override
    public int getBackgroundColor()
    {
        return Color.WHITE;
    }
    
    @Override
    public int getCursorColor()
    {
        return Color.GREEN;
    }
    
    @Override
    public int getLineCountColor()
    {
        return Color.BLACK;
    }
    
    @Override
    public int getLineRectColor()
    {
        return 0;
    }
    
    @Override
    public int getNormalColor()
    {
        return Color.DKGRAY;
    }
    
    @Override
    public int getSelectColor()
    {
        return 0x550099CC;
    }
    
}
