package com.frms.codeview.tools;

/**
 * 项目名称 ： app
 * 创建人 ： Frms
 * 创建人邮箱 ： 3505826836@qq.com
 * 创建时间 ：2020/2/22 20:42(ydt)
 */
public class Pair
{
    private int first;
    private int second;
    
    public Pair(int x, int y)
    {
        first = x;
        second = y;
    }
    
    public final int getFirst()
    {
        return first;
    }
    
    public final int getSecond()
    {
        return second;
    }
    
    public final void setFirst(int value)
    {
        first = value;
    }
    
    public final void setSecond(int value)
    {
        second = value;
    }
    
    public String toString()
    {
        return first + ", " + second;
    }
}
